// BaoHa Download Tool — background script (Chromium service worker / Firefox event page).
// Hands downloads, links and videos to BaoHaDownloadTool over native messaging, including cookies, referrer and UA.
"use strict";

const api = globalThis.browser ?? globalThis.chrome;
const HOST = "com.baoha.bhadm";
const NATIVE_TIMEOUT_MS = 8000;
const DEFAULTS = { capture: true, minSizeMB: 0 };

// Pages handled by yt-dlp in the desktop app (send page URL, not stream fragments).
const VIDEO_PAGE = /^https?:\/\/((www\.|m\.|music\.)?youtube\.com\/(watch|shorts\/|live\/|playlist\?|embed\/[\w-]{11})|(www\.)?youtube-nocookie\.com\/embed\/[\w-]{11}|youtu\.be\/|([a-z]+\.)?facebook\.com\/(.+\/videos\/(?!search\b)|reel\/\d|reels\/\d|watch\/?\?v=|share\/[rv]\/)|fb\.watch\/|(www\.)?tiktok\.com\/@[^/]+\/video\/|(www\.)?instagram\.com\/(reel|reels|p)\/|(www\.)?(x|twitter)\.com\/(?:[^/]+\/status|i\/web\/status)\/\d+|(www\.)?vimeo\.com\/\d+|(www\.)?dailymotion\.com\/video\/|(www\.)?bilibili\.com\/video\/)/i;

function cleanPageUrl(url) {
  try {
    const u = new URL(url);
    if (/(^|\.)facebook\.com$/i.test(u.hostname)) {
      for (const k of [...u.searchParams.keys()]) {
        if (/^(__cft__|__tn__|__eep__|__xts__|mibextid|rdid|share_url|fbclid)/i.test(k)) u.searchParams.delete(k);
      }
      u.hash = "";
      return u.href.replace(/\?$/, "");
    }
    if (/(^|\.)(x|twitter)\.com$/i.test(u.hostname)) {
      for (const k of [...u.searchParams.keys()]) {
        if (/^(s|t|ref_src|ref_url|mx)$/i.test(k)) u.searchParams.delete(k);
      }
      u.hash = "";
      return u.href.replace(/\?$/, "");
    }
    return url;
  } catch (e) {
    return url;
  }
}

const FRAGMENT_HOSTS = /(googlevideo\.com|fbcdn\.net|cdninstagram\.com|tiktokcdn|twimg\.com)$/i;

const FILE_EXTENSIONS = [
  "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "tgz", "tbz2", "z", "7zip", "cab",
  "exe", "msi", "msix", "msp", "apk", "xapk", "appx", "appxbundle", "dmg", "pkg", "deb", "rpm", "bin",
  "iso", "img", "vhd", "vhdx", "vmdk", "esd", "wim", "msu", "crx", "xpi",
  "mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "m4v", "ts", "m2ts", "3gp", "mpg", "mpeg", "vob",
  "mp3", "flac", "wav", "aac", "m4a", "ogg", "wma", "opus", "aiff", "alac", "ape", "mid", "midi",
  "pdf", "epub", "mobi", "azw3", "djvu", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "rtf",
  "torrent", "m3u8", "m3u", "mpd"
];
const FILE_LINK = new RegExp("\\.(" + FILE_EXTENSIONS.join("|") + ")([\\?&#]|$)", "i");
const IMAGE_LINK = /\.(jpe?g|png|gif|webp|bmp|svg|tiff?|avif|heic|ico)([\?&#]|$)/i;
const BINARY_MIME = /^(application\/(octet-stream|x-msdownload|exe|x-exe|dos-exe|x-winexe|msi|x-msi|zip|x-zip|x-zip-compressed|x-rar|x-rar-compressed|vnd\.rar|x-7z-compressed|x-tar|x-gzip|gzip|x-bzip2|x-bzip|x-xz|x-iso9660-image|pdf|vnd\.android\.package-archive|x-apple-diskimage|vnd\.ms-cab-compressed)|video\/|audio\/)/i;

async function settings() {
  const s = await api.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...s };
}

function isHttp(url) {
  return /^https?:\/\//i.test(url || "");
}

function originOf(url) {
  try { return new URL(url).origin; } catch (e) { return ""; }
}

// ------------------------------------------------------------------ native messaging

function sendNative(payload, timeoutMs = NATIVE_TIMEOUT_MS) {
  let timer;
  const req = globalThis.browser
    ? api.runtime.sendNativeMessage(HOST, payload)
    : new Promise((resolve, reject) => {
        try {
          api.runtime.sendNativeMessage(HOST, payload, answer => {
            const err = api.runtime.lastError;
            if (err) reject(new Error(err.message));
            else resolve(answer);
          });
        } catch (err) {
          reject(err);
        }
      });

  return Promise.race([
    req,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error("BaoHa connection timed out (8s)")), timeoutMs);
    })
  ]).finally(() => clearTimeout(timer));
}

function sanitizeCookie(c) {
  return {
    name: c.name,
    value: c.value,
    domain: c.domain,
    path: c.path,
    secure: c.secure,
    httpOnly: c.httpOnly,
    hostOnly: c.hostOnly,
    expirationDate: c.expirationDate
  };
}

async function cookiesForUrl(url, ref) {
  const map = new Map();
  const urls = [url, ref];
  for (const u of [url, ref]) {
    if (!u || !isHttp(u)) continue;
    try {
      const h = new URL(u).hostname.toLowerCase();
      if ((h === "x.com" || h.endsWith(".x.com")) && !urls.includes("https://twitter.com/")) urls.push("https://twitter.com/");
      else if ((h === "twitter.com" || h.endsWith(".twitter.com")) && !urls.includes("https://x.com/")) urls.push("https://x.com/");
    } catch (e) { }
  }
  for (const u of urls) {
    if (!u || !isHttp(u)) continue;
    try {
      const list = await api.cookies.getAll({ url: u });
      for (const c of list) {
        const key = c.name + "@" + (c.domain || "");
        if (!map.has(key)) map.set(key, sanitizeCookie(c));
      }
    } catch (e) { }
  }
  return [...map.values()];
}

async function sendToAppDetailed(items) {
  const full = [];
  const cache = new Map();
  for (const it of items) {
    if (!it || !it.url) continue;
    let cookies = it.cookies;
    if (!cookies) {
      const key = originOf(it.url) + " " + originOf(it.referrer);
      if (!cache.has(key)) cache.set(key, await cookiesForUrl(it.url, it.referrer));
      cookies = cache.get(key);
    }
    full.push({ ...it, cookies });
  }
  if (full.length === 0) return { ok: false, error: "No valid items" };
  try {
    const answer = await sendNative({ type: "download", userAgent: navigator.userAgent, items: full });
    if (answer && answer.ok) return { ok: true };
    return { ok: false, error: (answer && answer.error) || "BaoHa returned an invalid response" };
  } catch (e) {
    console.warn("BaoHa native host:", e);
    return { ok: false, error: String(e.message || e) };
  }
}

async function sendToApp(items) {
  const res = await sendToAppDetailed(items);
  return res.ok;
}

async function ping() {
  try {
    const answer = await sendNative({ type: "ping" });
    return answer && answer.ok
      ? { ...answer, extensionId: api.runtime.id }
      : { ok: false, error: "BaoHa returned an invalid response", extensionId: api.runtime.id };
  } catch (e) {
    return { ok: false, error: String(e.message || e), extensionId: api.runtime.id };
  }
}

async function restoreTabBadge(tabId) {
  if (tabId == null || tabId < 0) {
    try { await api.action.setBadgeText({ text: "" }); } catch (e) { }
    return;
  }
  try {
    const list = await getMedia(tabId);
    await api.action.setBadgeBackgroundColor({ color: "#0F766E", tabId });
    await api.action.setBadgeText({ text: list.length ? String(list.length) : "", tabId });
  } catch (e) { }
}

function flashBadge(text, color, tabId) {
  const target = tabId != null && tabId >= 0 ? { tabId } : {};
  try {
    api.action.setBadgeBackgroundColor({ color, ...target });
    api.action.setBadgeText({ text, ...target });
    setTimeout(() => restoreTabBadge(tabId), 3200);
  } catch (e) { }
}

// ------------------------------------------------------------------ download capture

let bypassUntil = 0;
const capturedDownloads = new Set();

async function handleDownloadItem(item) {
  if (capturedDownloads.has(item.id)) return true;

  const s = await settings();
  if (!s.capture) return false;
  if (Date.now() < bypassUntil) return false;

  const url = item.finalUrl || item.url;
  if (!isHttp(url)) return false;
  if (item.byExtensionId && item.byExtensionId === api.runtime.id) return false;

  const name = (item.filename || "").split(/[\\/]/).pop();
  const hasDownloadExt = FILE_LINK.test(name) || FILE_LINK.test(url) || VIDEO_PAGE.test(url);
  const isBinaryMime = BINARY_MIME.test(item.mime || "");
  if (!hasDownloadExt && !isBinaryMime) return false;

  const isTorrent = /\.torrent([\?&#]|$)/i.test(name) || /\.torrent([\?&#]|$)/i.test(url);
  const size = item.totalBytes || item.fileSize || 0;
  if (!isTorrent && s.minSizeMB > 0 && size > 0 && size < s.minSizeMB * 1024 * 1024) return false;

  const cookies = await cookiesForUrl(url, item.referrer || item.url);
  const ok = await sendToApp([{
    url,
    referrer: item.referrer || "",
    fileName: name,
    cookies
  }]);

  if (ok) {
    capturedDownloads.add(item.id);
    setTimeout(() => capturedDownloads.delete(item.id), 30000);
    flashBadge("✓", "#16A36A");
    return true;
  } else {
    flashBadge("!", "#E5484D");
    return false;
  }
}

if (api.downloads && api.downloads.onDeterminingFilename) {
  api.downloads.onDeterminingFilename.addListener((item, suggest) => {
    (async () => {
      try {
        const ok = await handleDownloadItem(item);
        if (ok) {
          try { await api.downloads.cancel(item.id); } catch (e) { }
          try { await api.downloads.erase({ id: item.id }); } catch (e) { }
        }
      } catch (e) {
        console.warn("BaoHa onDeterminingFilename error:", e);
      } finally {
        try { suggest(); } catch (e) { }
      }
    })();
    return true;
  });
} else if (api.downloads && api.downloads.onCreated) {
  api.downloads.onCreated.addListener(async item => {
    try {
      try { await api.downloads.pause(item.id); } catch (e) { }
      const ok = await handleDownloadItem(item);
      if (ok) {
        try { await api.downloads.cancel(item.id); } catch (e) { }
        try { await api.downloads.erase({ id: item.id }); } catch (e) { }
      } else {
        try { await api.downloads.resume(item.id); } catch (e) { }
      }
    } catch (e) {
      console.warn("BaoHa onCreated error:", e);
    }
  });
}

// ------------------------------------------------------------------ media sniffer (per tab)

const MEDIA_TYPES = /^(video\/|audio\/|application\/(vnd\.apple\.mpegurl|x-mpegurl|dash\+xml))/i;

function mediaKind(url, type) {
  const path = url.split("?")[0].toLowerCase();
  if (/mpegurl/i.test(type) || path.endsWith(".m3u8")) return "HLS";
  if (/dash\+xml/i.test(type) || path.endsWith(".mpd")) return "DASH";
  if (/^audio\//i.test(type)) return "AUDIO";
  return (path.match(/\.(mp4|webm|mkv|mov|flv|m4v|mp3|m4a)$/) || [, "VIDEO"])[1].toUpperCase();
}

async function getMedia(tabId) {
  const key = "media:" + tabId;
  return (await api.storage.session.get(key))[key] || [];
}

async function setMedia(tabId, list) {
  await api.storage.session.set({ ["media:" + tabId]: list });
  try {
    await api.action.setBadgeBackgroundColor({ color: "#0F766E", tabId });
    await api.action.setBadgeText({ text: list.length ? String(list.length) : "", tabId });
  } catch (e) { }
}

api.webRequest.onHeadersReceived.addListener(details => {
  if (details.tabId < 0 || !isHttp(details.url)) return;
  let host = "";
  try { host = new URL(details.url).hostname; } catch (e) { return; }
  if (FRAGMENT_HOSTS.test(host)) return;
  const header = (details.responseHeaders || []).find(h => h.name.toLowerCase() === "content-type");
  const type = header ? header.value || "" : "";
  const path = details.url.split("?")[0].toLowerCase();
  const isPlaylist = path.endsWith(".m3u8") || path.endsWith(".mpd");
  if (!MEDIA_TYPES.test(type) && !isPlaylist) return;
  if (/\.(ts|m4s)$/.test(path) || /\/(seg|segment|frag|chunk)[-_]?\d+/i.test(path)) return;
  const len = (details.responseHeaders || []).find(h => h.name.toLowerCase() === "content-length");
  const size = len ? parseInt(len.value, 10) || 0 : 0;
  if (!isPlaylist && size > 0 && size < 512 * 1024) return;

  (async () => {
    const list = await getMedia(details.tabId);
    const key = details.url.split("#")[0];
    if (list.some(m => m.url === key)) return;
    list.unshift({ url: key, kind: mediaKind(key, type), size, time: Date.now() });
    await setMedia(details.tabId, list.slice(0, 30));
  })();
}, { urls: ["<all_urls>"], types: ["media", "xmlhttprequest", "other"] }, ["responseHeaders"]);

api.tabs.onUpdated.addListener((tabId, info) => {
  if (info.url) setMedia(tabId, []);
});
api.tabs.onRemoved.addListener(tabId => api.storage.session.remove("media:" + tabId));

async function videoOfPage(tab, srcUrl, pageUrl, frameId = 0, contextMenu = false) {
  if (!tab || !isHttp(pageUrl || tab.url)) return null;
  const page = cleanPageUrl(pageUrl || tab.url);
  if (VIDEO_PAGE.test(page)) return { url: page, media: true, title: tab.title };

  if (tab.id != null && tab.url && /(^|\.)(x|twitter)\.com$/i.test(new URL(tab.url).hostname)) {
    try {
      const tweetUrl = await api.tabs.sendMessage(tab.id, { cmd: "resolveVideoPage", contextMenu }, { frameId });
      if (tweetUrl && VIDEO_PAGE.test(tweetUrl)) {
        return { url: cleanPageUrl(tweetUrl), media: true, title: tab.title };
      }
    } catch (e) { }
    return null;
  }

  if (isHttp(srcUrl)) {
    const playlist = /\.(m3u8|mpd)(\?|$)/i.test(srcUrl);
    return { url: srcUrl, referrer: tab.url, media: playlist, title: tab.title };
  }
  const seen = await getMedia(tab.id);
  const best = seen.find(m => m.kind === "HLS" || m.kind === "DASH") || seen.slice().sort((a, b) => b.size - a.size)[0];
  if (best) return { url: best.url, referrer: tab.url, media: best.kind === "HLS" || best.kind === "DASH", title: tab.title };
  return { url: page, media: true, title: tab.title };
}

// ------------------------------------------------------------------ context menus

let messages = null;

async function loadLanguage() {
  const { lang } = await api.storage.local.get({ lang: "auto" });
  messages = null;
  if (lang === "vi" || lang === "en") {
    try { messages = await (await fetch(api.runtime.getURL("_locales/" + lang + "/messages.json"))).json(); } catch (e) { }
  }
}

function t(key) {
  return (messages && messages[key] && messages[key].message) || api.i18n.getMessage(key) || key;
}

async function createMenus() {
  await loadLanguage();
  api.contextMenus.removeAll(() => {
    api.contextMenus.create({ id: "baoha-link", title: t("menuLink"), contexts: ["link"] });
    api.contextMenus.create({ id: "baoha-media", title: t("menuMedia"), contexts: ["video", "audio"] });
    api.contextMenus.create({ id: "baoha-page", title: t("menuPage"), contexts: ["page"] });
    api.contextMenus.create({ id: "baoha-all", title: t("menuAllLinks"), contexts: ["page"] });
    api.contextMenus.create({ id: "baoha-selection", title: t("menuSelection"), contexts: ["selection"] });
  });
}
api.runtime.onInstalled.addListener(createMenus);
api.runtime.onStartup.addListener(createMenus);
api.storage.onChanged.addListener((changes, area) => { if (area === "local" && changes.lang) createMenus(); });

function collectLinks() {
  const out = [];
  const add = (url, text) => { if (url) out.push([url, (text || "").replace(/\s+/g, " ").trim().slice(0, 200)]); };
  for (const a of document.querySelectorAll("a[href]")) add(a.href, a.textContent || a.title);
  for (const el of document.querySelectorAll("img, video, audio, source, embed, object")) {
    add(el.currentSrc || el.src || el.data, el.alt || el.title);
    const set = el.getAttribute && el.getAttribute("srcset");
    if (set) {
      const best = set.split(",").map(s => s.trim().split(/\s+/)).sort((a, b) => (parseFloat(b[1]) || 1) - (parseFloat(a[1]) || 1))[0];
      if (best && best[0]) {
        try { add(new URL(best[0], document.baseURI).href, el.alt); } catch (e) { }
      }
    }
  }
  return out;
}

async function allOfPage(tab) {
  if (!tab || !isHttp(tab.url)) return [];
  let found = [];
  try {
    const results = await api.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: collectLinks });
    for (const r of results || []) found = found.concat((r && r.result) || []);
  } catch (e) { }
  const items = new Map();
  for (const [raw, text] of found) {
    const url = cleanPageUrl(raw.split("#")[0]);
    if (items.has(url) || !(isHttp(url) || /^magnet:/i.test(url))) continue;
    if (/^magnet:/i.test(url) || FILE_LINK.test(url) || IMAGE_LINK.test(url))
      items.set(url, { url, referrer: tab.url });
    else if (VIDEO_PAGE.test(url) && url !== tab.url)
      items.set(url, { url, referrer: tab.url, media: true, title: text || undefined });
  }
  for (const m of await getMedia(tab.id)) {
    if (items.has(m.url)) continue;
    items.set(m.url, { url: m.url, referrer: tab.url, media: m.kind === "HLS" || m.kind === "DASH", title: tab.title });
  }
  return [...items.values()];
}

api.contextMenus.onClicked.addListener(async (info, tab) => {
  let items = [];
  if (info.menuItemId === "baoha-link") {
    const url = cleanPageUrl(info.linkUrl);
    items = [{ url, referrer: tab?.url || "", media: VIDEO_PAGE.test(url) }];
  } else if (info.menuItemId === "baoha-media") {
    items = [await videoOfPage(tab, info.srcUrl, info.pageUrl, info.frameId ?? 0, true)].filter(Boolean);
  } else if (info.menuItemId === "baoha-page") {
    items = [await videoOfPage(tab, null, info.pageUrl, info.frameId ?? 0, true)].filter(Boolean);
  } else if (info.menuItemId === "baoha-selection") {
    const urls = (info.selectionText || "").match(/(https?:\/\/[^\s"'<>]+|magnet:\?[^\s"'<>]+)/gi) || [];
    items = urls.map(url => ({ url, referrer: tab?.url || "", media: VIDEO_PAGE.test(url) }));
  } else if (info.menuItemId === "baoha-all") {
    items = await allOfPage(tab);
  }
  if (items.length === 0) return;
  const ok = await sendToApp(items);
  flashBadge(ok ? "✓" : "!", ok ? "#16A36A" : "#E5484D", tab?.id);
});

// ------------------------------------------------------------------ messages from popup / content script

api.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    if (msg.cmd === "bypassNext") {
      bypassUntil = Date.now() + 3000;
      return reply(true);
    }
    if (msg.cmd === "ping") return reply(await ping());
    if (msg.cmd === "getStartup") {
      try { return reply(await sendNative({ type: "getStartup" }, 4000)); }
      catch (e) { return reply({ ok: false, error: String(e.message || e) }); }
    }
    if (msg.cmd === "setStartup") {
      try { return reply(await sendNative({ type: "setStartup", enabled: !!msg.enabled }, 4000)); }
      catch (e) { return reply({ ok: false, error: String(e.message || e) }); }
    }
    if (msg.cmd === "media") return reply(msg.tabId != null ? await getMedia(msg.tabId) : []);
    if (msg.cmd === "send") return reply(await sendToAppDetailed(msg.items || []));
    if (msg.cmd === "all") {
      if (msg.tabId == null) return reply({ ok: false, count: 0 });
      const tab = await api.tabs.get(msg.tabId);
      const items = await allOfPage(tab);
      if (!items.length) return reply({ ok: false, count: 0 });
      const res = await sendToAppDetailed(items);
      return reply({ ok: res.ok, error: res.error, count: items.length });
    }
    if (msg.cmd === "pageVideo") {
      const tab = msg.tabId != null ? await api.tabs.get(msg.tabId) : sender.tab;
      const frameId = sender.frameId ?? 0;
      const inFrame = frameId !== 0 || msg.framed === true;
      const inner = msg.tabId == null && inFrame && !VIDEO_PAGE.test(cleanPageUrl(msg.pageUrl || ""));
      const item = inner
        ? await videoOfPage(tab, null, null)
        : await videoOfPage(tab, msg.framed ? null : msg.src, msg.pageUrl, frameId);
      if (!item) return reply(msg.detailed ? { ok: false, error: "No video found" } : false);
      const res = await sendToAppDetailed([item]);
      return reply(msg.detailed ? res : res.ok);
    }
    reply(null);
  })();
  return true;
});

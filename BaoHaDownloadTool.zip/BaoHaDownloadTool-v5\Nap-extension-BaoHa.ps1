﻿# Nap-extension-BaoHa.ps1
# Tự động đăng ký kết nối Native Messaging và nạp tiện ích BaoHa (extension\chromium và extension\firefox).
# Cách dùng: nhấn đúp Nap-extension-BaoHa.bat (cùng thư mục với BaoHaDownloadTool.exe).
#
# Tham số dòng lệnh (tùy chọn):
#   -Target all|chrome|firefox      Chọn nhóm trình duyệt (mặc định: all)
#   -SkipRepair                     Bỏ qua bước đăng ký kết nối (Sua-ket-noi-BaoHa.exe)
#   -LaunchApp                      Tự khởi chạy BaoHaDownloadTool.exe nếu chưa mở
#   -ChromePath  "...\chrome.exe"   Chỉ định trình duyệt Chromium riêng
#   -FirefoxPath "...\firefox.exe"  Chỉ định Firefox riêng
#   -FirefoxProfile "D:\profile"    Thư mục profile Firefox dùng với web-ext

param(
  [ValidateSet('all', 'chrome', 'firefox')]
  [string]$Target = 'all',
  [switch]$SkipRepair,
  [switch]$LaunchApp,
  [string]$ChromePath,
  [string]$FirefoxPath,
  [string]$FirefoxProfile
)

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$root      = $PSScriptRoot
$extChrome = Join-Path $root 'extension\chromium'
$extFx     = Join-Path $root 'extension\firefox'
$appExe    = Join-Path $root 'BaoHaDownloadTool.exe'

function Say([string]$msg, [string]$color = 'Gray') { Write-Host $msg -ForegroundColor $color }

function Find-First([string[]]$patterns) {
  foreach ($p in $patterns) {
    $expanded = [Environment]::ExpandEnvironmentVariables($p)
    $hit = Get-ChildItem -Path $expanded -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($hit) { return $hit.FullName }
  }
  return $null
}

function Test-Running([string]$exe) {
  $p = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $exe }
  return [bool]$p
}

Say '==========================================================' DarkCyan
Say '  BAOHA DOWNLOAD TOOL v5.5 — NAP TIEN ICH TRINH DUYET' Yellow
Say '==========================================================' DarkCyan
Say ''

# --- Kiểm tra môi trường ----------------------------------------------------
if ($root -match '\.zip(\\|$)') {
  Say 'Bạn đang chạy bên trong file ZIP. Hãy giải nén TOÀN BỘ ra một thư mục cố định rồi chạy lại.' Red
  exit 1
}

# --- Bước 1: đăng ký Native Messaging im lặng (/quiet) qua BaoHaDownloadTool.exe ---
if (-not $SkipRepair) {
  if (Test-Path $appExe) {
    Say '[1] Đăng ký kết nối Native Messaging cho thư mục này...' Cyan
    $proc = Start-Process -FilePath $appExe -ArgumentList '/quiet' -WorkingDirectory $root -Wait -PassThru
    if ($proc.ExitCode -eq 0) {
      Say '    [OK] Đã đăng ký Registry và kiểm tra ping BaoHa thành công.' Green
    } else {
      Say '    [Cảnh báo] Kiểm tra kết nối báo lỗi. Chạy "BaoHaDownloadTool.exe --ket-noi" để xem chi tiết.' Yellow
    }
  } else {
    Say '[1] Không thấy BaoHaDownloadTool.exe, bỏ qua bước đăng ký kết nối.' Yellow
  }
}

# --- Bước 2a: Trình duyệt họ Chromium ---------------------------------------
$usedClipboardForChrome = $false

function Invoke-Chromium {
  Say ''
  Say '[2] Nạp tiện ích cho trình duyệt họ Chromium...' Cyan

  if (-not (Test-Path (Join-Path $extChrome 'manifest.json'))) {
    Say "    Không thấy $extChrome\manifest.json" Red
    return
  }

  # Flag = $true: bản hỗ trợ cờ --load-extension
  $defs = @(
    @{ Name = 'Chromium / Chrome for Testing'; Flag = $true;  Url = 'chrome://extensions'; Paths = @(
        '%LOCALAPPDATA%\Chromium\Application\chrome.exe',
        '%ProgramFiles%\Chromium\Application\chrome.exe',
        '%LOCALAPPDATA%\ms-playwright\chromium-*\chrome-win*\chrome.exe') },
    @{ Name = 'Brave'; Flag = $true; Url = 'brave://extensions'; Paths = @(
        '%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe',
        '%ProgramFiles(x86)%\BraveSoftware\Brave-Browser\Application\brave.exe',
        '%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe') },
    @{ Name = 'Vivaldi'; Flag = $true; Url = 'vivaldi://extensions'; Paths = @(
        '%LOCALAPPDATA%\Vivaldi\Application\vivaldi.exe',
        '%ProgramFiles%\Vivaldi\Application\vivaldi.exe') },
    @{ Name = 'Google Chrome'; Flag = $false; AutoKey = 'chrome'; Url = 'chrome://extensions'; Paths = @(
        '%ProgramFiles%\Google\Chrome\Application\chrome.exe',
        '%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe',
        '%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe') },
    @{ Name = 'Microsoft Edge'; Flag = $false; AutoKey = 'edge'; Url = 'edge://extensions'; Paths = @(
        '%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe',
        '%ProgramFiles%\Microsoft\Edge\Application\msedge.exe') },
    @{ Name = 'Cốc Cốc'; Flag = $false; AutoKey = 'coccoc'; Url = 'coccoc://extensions'; Paths = @(
        '%ProgramFiles%\CocCoc\Browser\Application\browser.exe',
        '%ProgramFiles(x86)%\CocCoc\Browser\Application\browser.exe',
        '%LOCALAPPDATA%\CocCoc\Browser\Application\browser.exe') },
    @{ Name = 'Opera'; Flag = $false; AutoKey = ''; Url = 'opera://extensions'; Paths = @(
        '%LOCALAPPDATA%\Programs\Opera\opera.exe',
        '%LOCALAPPDATA%\Programs\Opera GX\opera.exe',
        '%ProgramFiles%\Opera\opera.exe') }
  )

  $found = @()
  if ($ChromePath) {
    if (Test-Path $ChromePath) {
      $found += [pscustomobject]@{ Name = 'Trình duyệt bạn chỉ định'; Exe = (Resolve-Path $ChromePath).Path; Flag = $true; AutoKey = ''; Url = 'chrome://extensions' }
    } else {
      Say "    -ChromePath không tồn tại: $ChromePath" Yellow
    }
  }
  foreach ($d in $defs) {
    $exe = Find-First $d.Paths
    if ($exe) { $found += [pscustomobject]@{ Name = $d.Name; Exe = $exe; Flag = $d.Flag; AutoKey = [string]$d.AutoKey; Url = $d.Url } }
  }

  if ($found.Count -eq 0) {
    Say '    Không tìm thấy trình duyệt Chromium nào. Dùng -ChromePath "đường\dẫn\chrome.exe" để chỉ định.' Yellow
    return
  }

  $chosen = $found
  if ($found.Count -gt 1) {
    Say '    Đã tìm thấy các trình duyệt:'
    for ($i = 0; $i -lt $found.Count; $i++) {
      $mode = if ($found[$i].Flag -or $found[$i].AutoKey) { 'tự động bật Developer mode & nạp nội bộ' } else { 'nạp thủ công 1 bước' }
      Say ("      {0}. {1}  ({2})" -f ($i + 1), $found[$i].Name, $mode)
    }
    $answer = Read-Host '    Chọn số (Enter = tất cả, 0 = bỏ qua)'
    if ($answer -eq '0') { return }
    $n = 0
    if ([int]::TryParse($answer, [ref]$n) -and $n -ge 1 -and $n -le $found.Count) {
      $chosen = @($found[$n - 1])
    }
  }

  foreach ($b in $chosen) {
    Say ''
    Say "    >> $($b.Name)" White
    if ($b.Flag) {
      if (Test-Running $b.Exe) {
        Say '       Trình duyệt đang mở. Hãy đóng hoàn toàn rồi chạy lại (nếu không cờ nạp extension bị bỏ qua).' Yellow
        continue
      }
      Start-Process -FilePath $b.Exe -ArgumentList @("--load-extension=`"$extChrome`"", '--no-first-run', $b.Url)
      Say '       Đã mở kèm tiện ích BaoHa.' Green
    } elseif ($b.AutoKey -and (Test-Path $appExe)) {
      Say '       Đang mở trang tiện ích, bật Chế độ nhà phát triển và nạp thư mục extension\chromium...' Cyan
      $p = Start-Process -FilePath $appExe -ArgumentList @("--install-$($b.AutoKey)") -WorkingDirectory $root -Wait -PassThru
      if ($p.ExitCode -eq 0) {
        Say '       [OK] Đã tự động bật Chế độ nhà phát triển và nạp tiện ích BaoHa!' Green
      } else {
        $script:usedClipboardForChrome = $true
        Say '       [Chú ý] Trình duyệt đã mở trang tiện ích và đường dẫn đã chép sẵn vào clipboard:' Yellow
        Say "       $extChrome" DarkGray
        Say '       -> Bật Developer mode -> Load unpacked -> Ctrl+V -> Select Folder.' Yellow
      }
    } else {
      Set-Clipboard -Value $extChrome
      $script:usedClipboardForChrome = $true
      Start-Process -FilePath $b.Exe -ArgumentList @($b.Url)
      Say '       Đã mở trang tiện ích và sao chép đường dẫn vào clipboard:' Green
      Say "       $extChrome" DarkGray
      Say '       -> Bật Developer mode -> Load unpacked -> dán đường dẫn (Ctrl+V) -> Select Folder.' Yellow
      Say '       -> Nếu còn bản BaoHa cũ trỏ tới thư mục phiên bản trước, hãy gỡ bản cũ trước.' Yellow
    }
  }
}

# --- Bước 2b: Firefox -------------------------------------------------------
function Invoke-Firefox {
  Say ''
  Say '[3] Nạp tiện ích cho Firefox...' Cyan

  if (-not (Test-Path (Join-Path $extFx 'manifest.json'))) {
    Say "    Không thấy $extFx\manifest.json" Red
    return
  }

  $fx = $null
  if ($FirefoxPath -and (Test-Path $FirefoxPath)) { $fx = (Resolve-Path $FirefoxPath).Path }
  if (-not $fx) {
    $fx = Find-First @(
      '%ProgramFiles%\Mozilla Firefox\firefox.exe',
      '%ProgramFiles(x86)%\Mozilla Firefox\firefox.exe',
      '%LOCALAPPDATA%\Mozilla Firefox\firefox.exe',
      '%ProgramFiles%\Firefox Developer Edition\firefox.exe',
      '%ProgramFiles%\Firefox Nightly\firefox.exe')
  }
  if (-not $fx) {
    Say '    Không tìm thấy Firefox. Bỏ qua bước này.' DarkGray
    return
  }

  $npx = Get-Command npx.cmd -ErrorAction SilentlyContinue
  if ($npx) {
    if (Test-Running $fx) {
      Say '    Firefox đang mở. Hãy đóng hoàn toàn rồi chạy lại để web-ext khởi động đúng.' Yellow
      return
    }
    $profileDir = if ($FirefoxProfile) { $FirefoxProfile } else { Join-Path $root '.firefox-profile' }
    $cmdFile = Join-Path $env:TEMP 'baoha-firefox-webext.cmd'
    $lines = @(
      '@echo off',
      'chcp 65001 >nul',
      'title BaoHa - Firefox (web-ext) - dong cua so nay de thoat',
      ('npx --yes web-ext run --source-dir "{0}" --firefox "{1}" --firefox-profile "{2}" --profile-create-if-missing --keep-profile-changes --no-config-discovery' -f $extFx, $fx, $profileDir),
      'pause'
    )
    [System.IO.File]::WriteAllText($cmdFile, ($lines -join "`r`n"), (New-Object System.Text.UTF8Encoding($false)))
    Start-Process -FilePath $cmdFile
    Say '    Đã chạy web-ext trong cửa sổ riêng (profile riêng, giữ đăng nhập giữa các lần).' Green
  } else {
    # Tránh ghi đè clipboard khi người dùng vừa mở Chromium cần dán đường dẫn Chromium!
    if ($script:usedClipboardForChrome) {
      Say '    Clipboard đang giữ đường dẫn Chromium ở bước trên.' Yellow
      $null = Read-Host '    Hãy dán xong cho Chromium rồi bấm Enter để tiếp tục sao chép manifest Firefox'
    }
    $manifest = Join-Path $extFx 'manifest.json'
    Set-Clipboard -Value $manifest
    Start-Process -FilePath $fx -ArgumentList @('about:debugging#/runtime/this-firefox')
    Say '    Đã mở about:debugging và sao chép đường dẫn manifest vào clipboard:' Green
    Say "    $manifest" DarkGray
    Say '    -> Load Temporary Add-on... -> dán đường dẫn (Ctrl+V) vào ô tên file -> Open.' Yellow
  }
}

if ($Target -in 'all', 'chrome')  { Invoke-Chromium }
if ($Target -in 'all', 'firefox') { Invoke-Firefox }

# --- Bước 3: Khởi chạy BaoHaDownloadTool nếu yêu cầu -----------------------
if ($LaunchApp -and (Test-Path $appExe) -and -not (Test-Running $appExe)) {
  Say ''
  Say '[4] Đang khởi chạy BaoHaDownloadTool.exe...' Cyan
  Start-Process -FilePath $appExe -WorkingDirectory $root
}

Say ''
Say 'Hoàn tất! Mở biểu tượng BaoHa trên thanh công cụ trình duyệt để kiểm tra trạng thái kết nối.' Green

@echo off
chcp 65001 >nul
cd /d "%~dp0"
title BaoHa Download Tool — Nap tien ich trinh duyet
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Nap-extension-BaoHa.ps1" %*
echo.
pause

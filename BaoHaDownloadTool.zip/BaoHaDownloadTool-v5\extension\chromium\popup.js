"use strict";
const api = globalThis.browser ?? globalThis.chrome;
const $ = id => document.getElementById(id);

function createDownloadIcon() {
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  const path = document.createElementNS(ns, "path");
  path.setAttribute("d", "M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z");
  svg.appendChild(path);
  return svg;
}

let messages = null;
const t = key => (messages && messages[key] && messages[key].message) || api.i18n.getMessage(key) || key;

async function loadLanguage(lang) {
  messages = null;
  if (lang === "vi" || lang === "en") {
    try { messages = await (await fetch("_locales/" + lang + "/messages.json")).json(); } catch (e) { }
  }
  document.documentElement.lang = lang === "auto" ? api.i18n.getUILanguage() : lang;
  for (const el of document.querySelectorAll("[data-i18n]")) el.textContent = t(el.dataset.i18n);
  $("retryConnection").title = t("popupRetry");
}

function formatSize(n) {
  if (!n) return "";
  const u = ["B", "KB", "MB", "GB"];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (i ? n.toFixed(n < 10 ? 1 : 0) : n) + " " + u[i];
}

let toastTimer = 0;
function toast(ok, text) {
  const el = $("toast");
  clearTimeout(toastTimer);
  el.hidden = false;
  el.className = ok ? "ok" : "bad";
  el.textContent = text || t(ok ? "popupSent" : "popupFailed");
  toastTimer = setTimeout(() => { el.hidden = true; }, 2800);
}

function isHttpUrl(url) {
  return /^https?:\/\//i.test(url || "");
}

function kindClass(kind) {
  const k = (kind || "").toUpperCase();
  if (k === "HLS") return "kind hls";
  if (k === "DASH") return "kind dash";
  if (k === "AUDIO" || k === "MP3" || k === "M4A") return "kind audio";
  return "kind";
}

async function init() {
  const { lang } = await api.storage.local.get({ lang: "auto" });
  await loadLanguage(lang);
  $("lang").value = lang;
  $("lang").onchange = async () => {
    await api.storage.local.set({ lang: $("lang").value });
    location.reload();
  };

  const [tab] = await api.tabs.query({ active: true, currentWindow: true });
  const webPage = !!(tab && isHttpUrl(tab.url));

  // Connection check
  const statusEl = $("status");
  const statusText = statusEl.querySelector(".status-text");
  const retryBtn = $("retryConnection");
  const retryInline = $("retryInline");
  const diagCard = $("connectionCard");
  const diagDetails = $("connectionDetails");

  async function checkConnection() {
    retryBtn.disabled = true;
    retryBtn.classList.add("spinning");
    retryInline.disabled = true;
    statusEl.classList.remove("ok", "bad");
    statusEl.classList.add("checking");
    statusText.textContent = t("popupChecking");

    try {
      let answer;
      try { answer = await api.runtime.sendMessage({ cmd: "ping" }); }
      catch (e) { answer = { ok: false, error: String(e.message || e) }; }

      const ok = !!(answer && answer.ok);
      statusEl.classList.remove("checking", "ok", "bad");
      statusEl.classList.add(ok ? "ok" : "bad");
      statusText.textContent = t(ok ? "popupConnected" : "popupNotConnected");
      diagCard.hidden = ok;
      diagDetails.textContent = ok
        ? ""
        : (answer?.error || t("popupNoResponse")) + "\nExtension ID: " + api.runtime.id;
      await syncStartupToggle(ok);
    } finally {
      retryBtn.disabled = false;
      retryBtn.classList.remove("spinning");
      retryInline.disabled = false;
    }
  }

  const startupInput = $("startWithWindows");
  async function syncStartupToggle(connected) {
    if (!connected) {
      startupInput.disabled = true;
      return;
    }
    try {
      const res = await api.runtime.sendMessage({ cmd: "getStartup" });
      if (res && res.ok) {
        startupInput.checked = !!res.startWithWindows;
        startupInput.disabled = false;
      } else {
        startupInput.disabled = true;
      }
    } catch (e) {
      startupInput.disabled = true;
    }
  }

  startupInput.onchange = async () => {
    const target = startupInput.checked;
    startupInput.disabled = true;
    try {
      const res = await api.runtime.sendMessage({ cmd: "setStartup", enabled: target });
      if (res && res.ok) {
        startupInput.checked = !!res.startWithWindows;
        toast(true, t(res.startWithWindows ? "popupStartupOn" : "popupStartupOff"));
      } else {
        startupInput.checked = !target;
        toast(false, t("popupFailed"));
      }
    } catch (e) {
      startupInput.checked = !target;
      toast(false, t("popupFailed"));
    } finally {
      startupInput.disabled = false;
    }
  };

  retryBtn.onclick = checkConnection;
  retryInline.onclick = checkConnection;
  $("copyError").onclick = async () => {
    try {
      await navigator.clipboard.writeText(diagDetails.textContent);
      toast(true, t("popupCopied"));
    } catch (e) {
      toast(false, t("popupCopyFailed"));
    }
  };
  await checkConnection();

  // Firefox MV3 site access check
  if (api.permissions && api.permissions.contains) {
    try {
      const granted = await api.permissions.contains({ origins: ["<all_urls>"] });
      if (!granted) {
        $("grant").hidden = false;
        $("grant").onclick = async () => {
          if (await api.permissions.request({ origins: ["<all_urls>"] })) $("grant").hidden = true;
        };
      }
    } catch (e) { }
  }

  // Page actions
  $("pageVideo").disabled = !webPage;
  $("pageAll").disabled = !webPage;

  $("pageVideo").onclick = async () => {
    if (!webPage) return;
    $("pageVideo").disabled = true;
    const res = await api.runtime.sendMessage({ cmd: "pageVideo", tabId: tab.id, detailed: true });
    $("pageVideo").disabled = false;
    const ok = !!(res && res.ok);
    toast(ok, ok ? t("popupSent") : (res?.error || t("popupFailed")));
  };

  $("pageAll").onclick = async () => {
    if (!webPage) return;
    $("pageAll").disabled = true;
    const r = await api.runtime.sendMessage({ cmd: "all", tabId: tab.id }) || { ok: false, count: 0 };
    $("pageAll").disabled = false;
    if (r.count === 0) toast(false, t("popupAllNone"));
    else toast(r.ok, r.ok ? r.count + " " + t("popupAllSent") : (r.error || t("popupFailed")));
  };

  // Detected media streams
  const list = tab ? (await api.runtime.sendMessage({ cmd: "media", tabId: tab.id }) || []) : [];
  const countEl = $("mediaCount");
  countEl.textContent = String(list.length);
  countEl.classList.toggle("has", list.length > 0);
  $("noMedia").hidden = list.length > 0;

  const ul = $("media");
  for (const m of list) {
    const li = document.createElement("li");
    const kind = document.createElement("span");
    kind.className = kindClass(m.kind);
    kind.textContent = m.kind;

    const url = document.createElement("span");
    url.className = "url";
    url.title = m.url;
    let display = m.url;
    try { display = decodeURIComponent(m.url.split("?")[0].split("/").pop() || m.url); } catch (e) { }
    url.textContent = display;

    const sz = document.createElement("span");
    sz.className = "size";
    sz.textContent = formatSize(m.size);

    const btn = document.createElement("button");
    btn.type = "button";
    btn.title = t("menuMedia");
    btn.appendChild(createDownloadIcon());
    btn.onclick = async () => {
      const media = m.kind === "HLS" || m.kind === "DASH";
      const res = await api.runtime.sendMessage({
        cmd: "send",
        items: [{ url: m.url, referrer: tab.url, media, title: tab.title }]
      });
      const ok = !!(res && res.ok);
      toast(ok, ok ? t("popupSent") : (res?.error || t("popupFailed")));
    };
    li.append(kind, url, sz, btn);
    ul.appendChild(li);
  }

  // Settings
  const s = await api.storage.local.get({ capture: true, minSizeMB: 0 });
  $("capture").checked = s.capture;
  $("minSize").value = s.minSizeMB;
  $("capture").onchange = () => api.storage.local.set({ capture: $("capture").checked });
  $("minSize").onchange = () => api.storage.local.set({ minSizeMB: Math.max(0, parseFloat($("minSize").value) || 0) });
}

init();

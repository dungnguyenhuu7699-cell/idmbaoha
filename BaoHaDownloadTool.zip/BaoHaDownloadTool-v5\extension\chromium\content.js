// BaoHa Download Tool — modern floating "BaoHa" download button over videos.
(() => {
  "use strict";
  if (window.__baohaDmInjected) return;
  window.__baohaDmInjected = true;

  const api = globalThis.browser ?? globalThis.chrome;
  const MIN_W = 240, MIN_H = 135;
  const VIDEO_LINK = /\/(watch\?v=|shorts\/|videos\/|reel\/|reels\/|status\/|watch\/?\?v=|video\/|share\/[rv]\/|p\/)/i;
  const NOT_VIDEO_LINK = /\/(hashtag|search|explore|tags?)\/|[?&]q=/i;

  let host, button, label, current = null, hideTimer = 0, overButton = false, lastMove = 0;
  let btnText = api.i18n.getMessage("overlayButton") || "BaoHa";
  let okText = "✓";
  let errText = "!";

  async function refreshLocale() {
    try {
      const { lang } = await api.storage.local.get({ lang: "auto" });
      const effective = lang === "auto" ? (api.i18n.getUILanguage() || "en") : lang;
      const isVi = /^vi/i.test(effective);
      btnText = api.i18n.getMessage("overlayButton") || "BaoHa";
      okText = isVi ? "Đã gửi" : "Sent";
      errText = isVi ? "Lỗi kết nối" : "Failed";
      if (label && !button.classList.contains("busy")) label.textContent = btnText;
    } catch (e) { }
  }
  refreshLocale();
  try {
    api.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.lang) refreshLocale();
    });
  } catch (e) { }

  function isVideoLink(url) {
    return VIDEO_LINK.test(url) && !NOT_VIDEO_LINK.test(url);
  }

  function isMainVideo(video) {
    const r = video.getBoundingClientRect();
    const mine = r.width * r.height;
    for (const v of document.getElementsByTagName("video")) {
      if (v === video) continue;
      const o = v.getBoundingClientRect();
      if (o.width * o.height > mine) return false;
    }
    return true;
  }

  function build() {
    host = document.createElement("baoha-dm-overlay");
    host.style.cssText = "all:initial;position:fixed;z-index:2147483647;top:0;left:0;display:none;";
    const shadow = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
      @keyframes bhPop {
        from { opacity: 0; transform: translateY(-4px) scale(.96); }
        to   { opacity: 1; transform: translateY(0) scale(1); }
      }
      button {
        all: unset;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 7px 13px 7px 10px;
        border-radius: 999px;
        font: 600 12.5px/1 "Segoe UI", system-ui, -apple-system, sans-serif;
        letter-spacing: .01em;
        color: #f8fafc;
        background: linear-gradient(135deg, rgba(11,56,70,.94), rgba(18,118,118,.94));
        border: 1px solid rgba(255,211,78,.5);
        box-shadow: 0 8px 24px rgba(5,20,28,.45), inset 0 1px 0 rgba(255,255,255,.18);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        transition: transform .15s ease, box-shadow .15s ease, background .15s ease, border-color .15s ease;
        user-select: none;
        white-space: nowrap;
        animation: bhPop .16s ease-out;
      }
      button:hover {
        transform: translateY(-1.5px);
        border-color: rgba(255,211,78,.88);
        box-shadow: 0 10px 28px rgba(5,20,28,.55), 0 0 0 3px rgba(255,211,78,.16);
      }
      button:active { transform: translateY(0) scale(.98); }
      button.busy { opacity: .88; pointer-events: none; }
      button.ok {
        background: linear-gradient(135deg, rgba(16,120,76,.96), rgba(22,163,106,.96));
        border-color: rgba(167,243,208,.75);
      }
      button.err {
        background: linear-gradient(135deg, rgba(175,38,48,.96), rgba(229,72,77,.96));
        border-color: rgba(254,202,202,.75);
      }
      svg { width: 15px; height: 15px; flex: none; }
      .ico { fill: #ffd34e; transition: transform .15s ease; }
      button:hover .ico { transform: translateY(1px); }
      button.ok .ico, button.err .ico { fill: #ffffff; }
    `;
    button = document.createElement("button");
    const NS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    const path = document.createElementNS(NS, "path");
    path.setAttribute("class", "ico");
    path.setAttribute("d", "M10.2,4H13.8V10.4H17.4L12,16.2L6.6,10.4H10.2Z M6.4,17.8H17.6A1.1,1.1 0 0,1 17.6,20H6.4A1.1,1.1 0 0,1 6.4,17.8Z");
    svg.appendChild(path);
    label = document.createElement("span");
    label.textContent = btnText;
    button.append(svg, label);
    button.addEventListener("mouseenter", () => { overButton = true; clearTimeout(hideTimer); });
    button.addEventListener("mouseleave", () => { overButton = false; scheduleHide(); });
    button.addEventListener("click", onClick, true);
    shadow.append(style, button);
    (document.body || document.documentElement).appendChild(host);
  }

  function videoPageUrl(video) {
    const here = location.href;
    if (/(^|\.)(x|twitter)\.com$/i.test(location.hostname)) return xVideoPageUrl(video);
    if (isVideoLink(location.pathname + location.search) && !/facebook\.com\/?$/.test(here)) {
      const r = video.getBoundingClientRect();
      if (r.width >= window.innerWidth * 0.45 || isMainVideo(video)) return here;
    }
    const post = video.closest && video.closest("article, [data-testid='tweet']");
    if (post) {
      for (const a of post.querySelectorAll("a[href*='/status/']")) {
        if (isVideoLink(a.href)) return a.href;
      }
    }
    let el = video;
    for (let i = 0; i < 25 && el; i++, el = el.parentElement) {
      if (el.matches && el.matches("a[href]") && isVideoLink(el.href)) return el.href;
      if (!el.querySelectorAll) continue;
      for (const a of el.querySelectorAll("a[href*='/videos/'], a[href*='/reel/'], a[href*='/reels/'], a[href*='/status/'], a[href*='/watch'], a[href*='/shorts/'], a[href*='/video/']"))
        if (isVideoLink(a.href)) return a.href;
    }
    return here;
  }

  function xVideoPageUrl(video) {
    function permalink(raw) {
      try {
        const url = new URL(raw, location.href);
        if (!/(^|\.)(x|twitter)\.com$/i.test(url.hostname)) return "";
        const match = url.pathname.match(/^\/(?:[^/]+\/status|i\/web\/status)\/(\d+)(?:\/|$)/i);
        return match ? url.origin + url.pathname.slice(0, url.pathname.indexOf(match[1]) + match[1].length) : "";
      } catch { return ""; }
    }
    const post = video?.closest("article, [data-testid='tweet']");
    for (let node = video; node && node !== document.body; node = node.parentElement) {
      if (node.matches("a[href]")) {
        const url = permalink(node.href);
        if (url) return url;
      }
      const links = [...node.querySelectorAll("a[href*='/status/']")].filter(a => {
        if (a.closest("article, [data-testid='tweet']") !== post) return false;
        for (let parent = a.parentElement; parent && parent !== node; parent = parent.parentElement) {
          if (parent.matches("[data-testid='quoteTweet'], [role='link']") && !parent.contains(video)) return false;
        }
        return true;
      });
      links.sort((a, b) => Number(!!b.querySelector("time") || /\/video\/\d+/.test(b.pathname))
        - Number(!!a.querySelector("time") || /\/video\/\d+/.test(a.pathname)));
      for (const a of links) {
        const url = permalink(a.href);
        if (url) return url;
      }
      if (node === post) break;
    }
    return (!post && isMainVideo(video)) ? permalink(location.href) : "";
  }

  async function onClick(e) {
    e.preventDefault();
    e.stopPropagation();
    if (current?.fromFrame ? !current.frame.isConnected : !current?.isConnected) return;
    const src = current.fromFrame ? "" : current.currentSrc || current.src || "";
    button.classList.remove("ok", "err");
    button.classList.add("busy");
    label.textContent = "...";
    try {
      const ok = await api.runtime.sendMessage(current.fromFrame
        ? { cmd: "pageVideo", pageUrl: current.page, src: "", framed: true }
        : { cmd: "pageVideo", pageUrl: videoPageUrl(current), src: /^https?:/i.test(src) ? src : "" });
      button.classList.add(ok ? "ok" : "err");
      label.textContent = ok ? okText : errText;
    } catch (err) {
      button.classList.add("err");
      label.textContent = errText;
    }
    setTimeout(() => {
      label.textContent = btnText;
      button.classList.remove("busy", "ok", "err");
    }, 2000);
  }

  function place(video) {
    if (!host) build();
    const r = rectOf(video);
    host.style.display = "block";
    const w = button.offsetWidth || 86;
    host.style.left = Math.max(6, Math.min(window.innerWidth - w - 8, r.right - w - 12)) + "px";
    host.style.top = Math.max(6, r.top + 12) + "px";
  }

  function scheduleHide() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      if (overButton) return;
      current = null;
      if (host) host.style.display = "none";
    }, 900);
  }

  const FRAME_MSG = "__baohaDmFrameVideos";
  const remotes = new Map();

  function frameOf(source) {
    for (const f of document.querySelectorAll("iframe, frame"))
      if (f.contentWindow === source) return f;
    return null;
  }

  window.addEventListener("message", e => {
    const d = e.data;
    if (!d || typeof d !== "object" || !Array.isArray(d[FRAME_MSG])) return;
    const frame = frameOf(e.source);
    if (!frame) return;
    const videos = d[FRAME_MSG].filter(v => v && [v.x, v.y, v.w, v.h].every(Number.isFinite) && typeof v.page === "string").slice(0, 8);
    if (videos.length) remotes.set(frame, { at: Date.now(), videos });
    else remotes.delete(frame);
  });

  function remoteVideos() {
    const out = [], now = Date.now();
    for (const [frame, entry] of remotes) {
      if (!frame.isConnected || now - entry.at > 3000) { remotes.delete(frame); continue; }
      for (const v of entry.videos) out.push({ fromFrame: true, frame, page: v.page, x: v.x, y: v.y, w: v.w, h: v.h });
    }
    return out;
  }

  function rectOf(target) {
    if (!target.fromFrame) return target.getBoundingClientRect();
    const f = target.frame.getBoundingClientRect();
    const left = f.left + target.frame.clientLeft + target.x, top = f.top + target.frame.clientTop + target.y;
    return { left, top, right: left + target.w, bottom: top + target.h, width: target.w, height: target.h };
  }

  function reportToParent() {
    const list = [];
    const vw = window.innerWidth, vh = window.innerHeight;
    let hidden = false;
    for (const v of document.getElementsByTagName("video")) {
      const r = v.getBoundingClientRect();
      if (r.width < MIN_W || r.height < MIN_H) continue;
      const x = Math.max(0, r.left), y = Math.max(0, r.top);
      const w = Math.min(vw, r.right) - x, h = Math.min(vh, r.bottom) - y;
      if (w >= MIN_W && h >= MIN_H) list.push({ x, y, w, h, page: location.href });
      else hidden = true;
    }
    if (list.length === 0 && hidden && vw >= MIN_W && vh >= MIN_H) list.push({ x: 0, y: 0, w: vw, h: vh, page: location.href });
    for (const t of remoteVideos()) {
      const r = rectOf(t);
      list.push({ x: r.left, y: r.top, w: r.width, h: r.height, page: t.page });
    }
    if (list.length === 0 && !reportToParent.sent) return;
    reportToParent.sent = list.length > 0;
    try { window.parent.postMessage({ [FRAME_MSG]: list }, "*"); } catch (err) { }
  }
  if (window.parent !== window) setInterval(reportToParent, 1000);

  function videoAt(x, y) {
    let best = null, area = 0;
    for (const v of [...document.getElementsByTagName("video"), ...remoteVideos()]) {
      const r = rectOf(v);
      if (r.width < MIN_W || r.height < MIN_H) continue;
      if (x < r.left || x > r.right || y < r.top || y > r.bottom) continue;
      const a = r.width * r.height;
      if (a > area) { best = v; area = a; }
    }
    return best;
  }

  document.addEventListener("mousemove", e => {
    if (host && e.composedPath().includes(host)) return;
    const now = performance.now();
    if (now - lastMove < 80) return;
    lastMove = now;
    const v = videoAt(e.clientX, e.clientY);
    if (v) {
      clearTimeout(hideTimer);
      current = v;
      window.__baohaCurrentVideo = v;
      place(v);
    } else if (current && !overButton) {
      scheduleHide();
    }
  }, { passive: true, capture: true });

  window.addEventListener("scroll", () => { if (current && host && host.style.display !== "none") place(current); }, { passive: true, capture: true });
  document.addEventListener("fullscreenchange", () => {
    if (!host) return;
    const fs = document.fullscreenElement;
    (fs && fs !== document.documentElement ? fs : (document.body || document.documentElement)).appendChild(host);
  });

  window.addEventListener("contextmenu", e => {
    window.__baohaLastTarget = e.target;
    window.__baohaContextVideo = e.target.closest?.("video") || videoAt(e.clientX, e.clientY);
  }, { capture: true, passive: true });

  api.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg.cmd !== "resolveVideoPage") return;
    const video = msg.contextMenu ? window.__baohaContextVideo : current || window.__baohaCurrentVideo;
    reply(video?.isConnected ? videoPageUrl(video) : "");
  });

  window.addEventListener("click", e => {
    if (e.altKey) {
      try { api.runtime.sendMessage({ cmd: "bypassNext" }); } catch (err) { }
    }
  }, true);
})();
